

//EXERCIce 2.1 

public class Author { 
private String name;
private String email;
private char gender;

public Author(String name, String email, char gender) {
    this.name = name;
    this.email = email;
    this.gender = gender;
}

public String getName() {
    return name;
    }

public String getEmail() {
    return email;

public void setEmail(String newEmail) {
    email = newEmail; 
    }

public char getGender() {
    return gender; 
}

public String toString() {
    return "Author[name=" + name + ", email=" + email + ", gender=" + gender +
"]";
    }
}

public class TestAuthor { 
public static void main(String[] args) {
    Author ahTeck = new Author("Tan Ah Teck", "ahteck@nowhere.com", 'm');
    System.out.println(ahTeck); 
    ahTeck.setEmail("paulTan@nowhere.com");
    System.out.println("name is: " + ahTeck.getName());
    System.out.println("email is: " + ahTeck.getEmail());
    System.out.println("gender is: " + ahTeck.getGender());
}
}
public class Book { 


private String name;
private Author author;
private double price;
private int qty;
public Book(String name, Author author, double price) {
    this.name = name;
    this.author = author;
    this.price = price;
    }
public Book(String name, Author author, double price, int qty) {
    this.name = name;
    this.author = author;
    this.price = price;
    this.qty = qty;
}
public String getName() {
    return name;
    }
public Author getAuthor() {
    return author;
    }
public double getPrice() {
    return price;
}

//2.2
import java.util.Scanner;

public class TP4{
    public static void main(String[] args){
        isBinary();

    }
    public static void isBinary(){
        String chaine;
        Scanner in = new Scanner(System.in);
        System.out.println("entrez une chaine:");
        chaine = in.nextLine();
        in.close();
        for(int i= 0 ; i<chaine.length() ;++i ){
            if(chaine.charAt(i) != '0' || chaine.charAt(i) != '1'){
                System.out.print(i);
                System.out.println("ce n'est pas un nombre binaire");
                System.exit(-1);
            }
            else{
                System.out.print(i);
            }
        
        }
        System.out.println("c'est un nombre binaire");

                
    }
}


